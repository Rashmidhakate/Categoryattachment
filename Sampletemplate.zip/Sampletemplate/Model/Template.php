<?php
namespace Commercepundit\Sampletemplate\Model;
class Template extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Commercepundit\Sampletemplate\Model\ResourceModel\Template');
    }
}

